import NetlifyForm from "@quarkly/community-kit/NetlifyForm";
export default NetlifyForm;